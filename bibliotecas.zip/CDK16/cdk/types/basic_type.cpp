#include <cdk/types/basic_type.h>

// the horror! (but required)
cdk::basic_type::~basic_type() noexcept {
  // EMPTY
}
