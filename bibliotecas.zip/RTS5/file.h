#ifndef __RTS_FILE_H__
#define __RTS_FILE_H__

void fprints(int fd, const char *str);
char freadb(int fd);

#endif
