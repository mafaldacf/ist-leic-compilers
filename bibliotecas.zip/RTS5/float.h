#ifndef __RTS_FLOAT_H__
#define __RTS_FLOAT_H__

double atod(const char *s);
char *dtoa(double d, int ndig, char *s);

#endif
